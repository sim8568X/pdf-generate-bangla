<?php

namespace App\Services\CarParking;

class CarParking
{
    /**
     * @return string
     */
    public function showParkingStatus()
    {
        return 'static address';
    }
}
