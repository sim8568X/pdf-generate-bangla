<?php

namespace App\Services\CarWashing;

class CarWashing
{

    /**
     * @return string
     */
    public function showWashStatus()
    {
        return 'status is washed';
    }
}
