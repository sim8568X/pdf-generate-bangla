<?php

return [
    'modules' => [
        Vanilo\Foundation\Providers\ModuleServiceProvider::class
    ],
    'register_route_models' => true
];
