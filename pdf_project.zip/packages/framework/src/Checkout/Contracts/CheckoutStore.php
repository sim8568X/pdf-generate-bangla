<?php

declare(strict_types=1);

/**
 * Contains the CheckoutStore interface.
 *
 * @copyright   Copyright (c) 2017 Attila Fulop
 * @author      Attila Fulop
 * @license     MIT
 * @since       2017-11-23
 *
 */

namespace Vanilo\Checkout\Contracts;

interface CheckoutStore extends Checkout
{
}
