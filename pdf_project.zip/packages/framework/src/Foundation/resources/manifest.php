<?php

declare(strict_types=1);

return [
    'name' => 'Vanilo Foundation',
    'version' => '3.5-dev'
];
