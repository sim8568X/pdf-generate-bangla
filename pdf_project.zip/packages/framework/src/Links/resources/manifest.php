<?php

declare(strict_types=1);

return [
    'name' => 'Vanilo Links Module',
    'version' => '3.5-dev'
];
